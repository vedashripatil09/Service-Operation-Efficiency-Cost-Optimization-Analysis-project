import streamlit as st
from modules.auth import login, is_logged_in
from modules.db import load_data
import modules.dashboard as dashboard
import modules.admin as admin

# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="ServiceOps Dashboard", layout="wide")

# ---------------- LOAD CSS ----------------
with open("assets/style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# ---------------- LOAD DATA ----------------
load_data()

# ---------------- LOGIN ----------------
login()

if not is_logged_in():
    st.warning("🔐 Please login to continue")
    st.stop()

# ---------------- SIDEBAR ----------------
st.sidebar.image(
    "https://cdn-icons-png.flaticon.com/512/1046/1046857.png",
    width=60
)

st.sidebar.markdown("## ServiceOps")
st.sidebar.markdown("---")

# MENU
st.sidebar.title("📊 Menu")
page = st.sidebar.radio(
    "",
    ["Dashboard", "Upload Data", "About"]
)

# ---------------- ROUTING ----------------
if page == "Dashboard":
    dashboard.run()

elif page == "Upload Data":
    admin.run()

elif page == "About":
    st.title("About")
    st.write("Service Operation Efficiency & Cost Optimization Analysis Dashboard")

# ---------------- FOOTER ----------------
st.sidebar.markdown("---")
st.sidebar.caption("© 2026 ServiceOps Dashboard")