/* Average resolution time by issue type*/
SELECT issue_type,
        AVG(resolution_hours) AS avg_hours
FROM service_calls
GROUP BY issue_type;

/* Average cost by issue type*/
SELECT sc.issue_type,
        AVG(s.total_cost) as avg_cost
FROM service_calls sc
JOIN service_costs s ON sc.service_id = s.service_id
GROUP BY sc.issue_type;

/* Average resolution time by technician*/
SELECT technician_id,
AVG(resolution_hours) AS avg_hours
FROM service_calls
GROUP BY technician_id
ORDER BY avg_hours;

/*AMC vs Non-AMC cost comparison*/
SELECT c.contract_type,
AVG(s.total_cost) AS avg_cost
FROM service_calls sc  
JOIN service_costs s ON sc.service_id = s.service_id
JOIN clients c ON sc.client_id = c.client_id
GROUP BY c.contract_type;

/*Top 5 most expensive service calls*/
SELECT sc.service_id,
       sc.issue_type,
       s.total_cost
FROM service_calls sc
JOIN service_costs s ON sc.service_id = s.service_id
ORDER BY s.total_cost DESC;

/* Technician workload (number of services handled)*/
SELECT technician_id,
COUNT(service_id) AS total_services
FROM service_calls
GROUP BY technician_id
ORDER BY total_services DESC;

/* Avg resolution time by region*/
SELECT c.region,
AVG(resolution_hours) AS avg_hours
FROM service_calls sc  
JOIN clients c ON sc.client_id = c.client_id
GROUP BY c.region;

/* Identify slow & expensive services*/
SELECT sc.service_id,
       sc.issue_type,
       s.total_cost,
        sc.resolution_hours
FROM service_calls sc   
JOIN service_costs s ON sc.service_id = s.service_id
WHERE sc.resolution_hours > 8 AND s.total_cost > 5000
ORDER BY s.total_cost DESC;


/* SLA breach count*/
SELECT issue_type,
COUNT(*) AS total_services,
SUM(CASE WHEN resolution_hours > 6 THEN 1 ELSE 0 END) AS sla_breaches
FROM service_calls
GROUP BY issue_type;

/* COST PER HOUR*/
SELECT sc.issue_type,
AVG(s.total_cost / sc.resolution_hours) AS cost_per_hour
FROM service_calls sc  
JOIN service_costs s ON sc.service_id = s.service_id
GROUP BY sc.issue_type;

/* Technician performance score*/
SELECT sc.technician_id,
       ROUND(AVG(sc.resolution_hours),2) AS avg_time,
       ROUND(AVG(s.total_cost),2) AS avg_cost
FROM service_calls sc
JOIN service_costs s ON sc.service_id = s.service_id
GROUP BY sc.technician_id;

/* CONTRACT RISK ANALYSIS*/
SELECT c.contract_type,
       ROUND(AVG(s.total_cost),2) AS avg_cost,
       ROUND(AVG(sc.resolution_hours),2) AS avg_time
FROM service_calls sc
JOIN service_costs s ON sc.service_id = s.service_id
JOIN clients c ON sc.client_id = c.client_id
GROUP BY c.contract_type;