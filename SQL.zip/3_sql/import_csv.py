import sqlite3
import csv
import os
from pathlib import Path

# Get the database and data paths
script_dir = Path(__file__).parent
db_path = script_dir / "service_ops.db"
data_dir = script_dir.parent / "1_data"

# Connect to the database
conn = sqlite3.connect(str(db_path))
cursor = conn.cursor()

# Create tables
print("Creating tables...")
cursor.executescript("""
CREATE TABLE IF NOT EXISTS clients (
    client_id TEXT PRIMARY KEY,
    industry TEXT NOT NULL,
    contract_type TEXT NOT NULL,
    region TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS technicians (
    technician_id TEXT PRIMARY KEY,
    experience_years INTEGER NOT NULL,
    region TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS service_calls (
    service_id TEXT PRIMARY KEY,
    client_id TEXT NOT NULL,
    technician_id TEXT NOT NULL,
    service_date TEXT NOT NULL,
    issue_type TEXT NOT NULL,
    resolution_hours REAL NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (technician_id) REFERENCES technicians(technician_id)
);

CREATE TABLE IF NOT EXISTS service_costs (
    service_id TEXT PRIMARY KEY,
    travel_cost INTEGER NOT NULL,
    parts_cost INTEGER NOT NULL,
    labor_cost INTEGER NOT NULL,
    total_cost INTEGER NOT NULL,
    FOREIGN KEY (service_id) REFERENCES service_calls(service_id)
);
""")

# Import function
def import_csv(csv_file, table_name):
    csv_path = data_dir / csv_file
    print(f"Importing {csv_file} into {table_name}...")
    
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        
        if rows:
            columns = list(rows[0].keys())
            placeholders = ','.join(['?' for _ in columns])
            insert_sql = f"INSERT INTO {table_name} ({','.join(columns)}) VALUES ({placeholders})"
            
            for row in rows:
                values = [row[col] for col in columns]
                cursor.execute(insert_sql, values)
            
            conn.commit()
            print(f"  ✓ Imported {len(rows)} rows")

# Import all CSV files
import_csv("clients.csv", "clients")
import_csv("technicians.csv", "technicians")
import_csv("service_calls.csv", "service_calls")
import_csv("service_costs.csv", "service_costs")

# Show summary
print("\n" + "="*50)
print("IMPORT SUMMARY")
print("="*50)

tables = ["clients", "technicians", "service_calls", "service_costs"]
for table in tables:
    cursor.execute(f"SELECT COUNT(*) FROM {table}")
    count = cursor.fetchone()[0]
    print(f"{table:20} : {count:,} rows")

conn.close()
print("\n✓ Import completed successfully!")
