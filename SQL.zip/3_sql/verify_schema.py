import sqlite3

conn = sqlite3.connect('service_ops.db')
cursor = conn.cursor()

print('Database Schema:')
print('='*60)
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cursor.fetchall()
for table in tables:
    print(f'\nTable: {table[0]}')
    cursor.execute(f'PRAGMA table_info({table[0]})')
    for col in cursor.fetchall():
        print(f'  {col[1]:20} {col[2]:10}')

print('\n' + '='*60)
print('Sample Data:')
print('='*60)

# Sample from clients
print('\nClients (first 3):')
cursor.execute('SELECT * FROM clients LIMIT 3')
for row in cursor.fetchall():
    print(f'  {row}')

# Sample from service_calls
print('\nService Calls (first 3):')
cursor.execute('SELECT * FROM service_calls LIMIT 3')
for row in cursor.fetchall():
    print(f'  {row}')

conn.close()
